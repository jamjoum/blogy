package com.blogy.restful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogyApplication.class, args);
	}

}
